const express = require("express"); 
const billAppI = express();
const crypto = require('crypto'); 
const bodyParser = require("body-parser");
const request = require('request');


billAppI.use(bodyParser.json());
billAppI.use(bodyParser.urlencoded({extended : true}));

Date.prototype.YYYYMMDDHHMMSS = function () {
    var yyyy = this.getFullYear().toString();
    var MM = pad(this.getMonth() + 1,2);
    var dd = pad(this.getDate(), 2);
    var hh = pad(this.getHours(), 2);
    var mm = pad(this.getMinutes(), 2)
    var ss = pad(this.getSeconds(), 2)
  
    return yyyy +  MM + dd+  hh + mm + ss;
};
  
function pad(number, length) {
    var str = '' + number;
    while (str.length < length) {
      str = '0' + str;
    }
    return str;
}
      
var nowDate = new Date();
var HashMap = require ('hashmap');
    

//step1. 요청을 위한 파라미터 설정
const key = "rKnPljRn5m6J9Mzz";    
const type = "Billing";
const paymethod = "Card";
const timestamp = nowDate.YYYYMMDDHHMMSS();
const clientIp = "111.222.333.889";
const mid = "INIBillTst";	
const url = "https://www.inicis.com";	
const moid = "oid_12345";				
const goodName = "Test";					
const buyerName = "홍길동";				
const buyerEmail = "test@inicis.com";		
const buyerTel = "01012341234";			
const price = "100";					
const billKey = "";	//빌키 입력 필요
const authentification = "00";	//본인인증 여부 ["00" 고정] //본인인증 안함 가맹점으로 별도 계약된 경우 "99"			

// Hash Encryption
const data_hash = key + type + paymethod + timestamp + clientIp + mid + moid + price + billKey;
const hashData = crypto.createHash('sha512').update(data_hash).digest('hex');

const apiUrl = "https://iniapi.inicis.com/api/v1/billing"


let options = {
    type : type,
    paymethod : paymethod,
    timestamp : timestamp,
    clientIp : clientIp,
    mid : mid,
    url : url,
    moid : moid,
    goodName : goodName,
    buyerName : buyerName,
    buyerEmail : buyerEmail,
    buyerTel : buyerTel,
    price : price,
    billKey : billKey,
    authentification : authentification,
    hashData : hashData
}


request.post({method: 'POST', uri: apiUrl, form: options}, (err,httpResponse,body) =>{ 
    console.log(body)
});

